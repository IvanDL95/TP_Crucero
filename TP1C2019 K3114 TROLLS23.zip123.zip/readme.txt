N�mero de grupo:23
Nombre y legajo de los integrantes:
De Luca, Iv�n 158907-6
G�mez Gar�n, Gustavo 151388-6
Email del integrante responsable del grupo: gggarin@hotmail.com
